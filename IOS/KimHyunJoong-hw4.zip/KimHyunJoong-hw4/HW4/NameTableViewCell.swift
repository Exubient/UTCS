//
//  NameTableViewCell.swift
//  HW4
//
//  Created by Hyun Joong Kim on 2/15/17.
//  Copyright © 2017 Hyun Joong Kim. All rights reserved.
//

import UIKit

class NameTableViewCell: UITableViewCell{
    //Declare an action to be run
    var row:Int?
    var alertController:UIAlertController?

    @IBOutlet weak var tap: UIButton!
    @IBOutlet weak var nameText: UILabel!
    @IBOutlet weak var firstnameText: UILabel!
    @IBOutlet weak var lastnameText: UILabel!
    @IBOutlet weak var ageText: UILabel!
    
    @IBAction func actionTap(_ sender:AnyObject){
        self.alertController = UIAlertController(title: "Person", message: "\(firstnameText.text!) \(lastnameText.text!) \(ageText.text!)", preferredStyle: UIAlertControllerStyle.alert)
    let OK = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default){(action:UIAlertAction)in}
    self.alertController!.addAction(OK)
        UIApplication.shared.keyWindow?.rootViewController?.present(alertController!, animated:true, completion:nil)
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        ageText.isHidden = true
}

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
