//
//  class_person.swift
//  KimHyunJoong-HW3
//
//  Created by Hyun Joong Kim on 2/6/17.
//  Copyright © 2017 Hyun Joong Kim. All rights reserved.
//

//
//  File.swift
//  KimHyunJoong-hw1
//
//  Created by Hyun Joong Kim on 1/23/17.
//  Copyright © 2017 Hyun Joong Kim. All rights reserved.
//
import Foundation

class Person {
    public var firstname:String?
    public var lastname:String?
    public var age:Int?
    public var city:String?
    
    init (firstname:String , lastname:String, age:Int, city:String){
        self.firstname = firstname
        self.lastname = lastname
        self.age = age
        self.city = city
        
    }
}
