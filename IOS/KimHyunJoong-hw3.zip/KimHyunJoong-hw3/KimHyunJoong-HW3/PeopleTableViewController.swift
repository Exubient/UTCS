//
//  PeopleTableViewController.swift
//  KimHyunJoong-HW3
//
//  Created by Hyun Joong Kim on 2/6/17.
//  Copyright © 2017 Hyun Joong Kim. All rights reserved.
//

import UIKit

class PeopleTableViewController: UITableViewController {
    
    private var people = [Person]()
    
    public func createDataModel(){
        let p1 = Person(firstname:"Bob" , lastname:"Carpenter", age:35, city:"Austin")
        let p2 = Person(firstname:"John" , lastname:"Jones", age:8, city:"Boston")
        let p3 = Person(firstname: "Led", lastname: "Zeppeling", age: 73, city: "Paris")
        let p4 = Person(firstname: "Sam", lastname: "Smith", age: 34, city: "Sydney")
        let p5 = Person(firstname: "June", lastname: "Johnson", age: 12, city: "Vienna")
        let p6 = Person(firstname: "Allison", lastname: "Atwater", age: 21, city: "Venice")
        let p7 = Person(firstname: "Donald", lastname: "Trump", age: 56, city: "Munich")
        let p8 = Person(firstname: "Hillary", lastname: "Clinton", age: 69, city: "Brussels")
        let p9 = Person(firstname: "Barrack", lastname: "Obama", age: 53, city: "Tokyo")
        let p10 = Person(firstname: "Teddy", lastname: "Roosevelt", age: 70, city: "Shanhai")
        people = [p1, p2, p3, p4, p5, p6, p7, p8, p9, p10]
    }
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        createDataModel()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 10
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        if let label = cell.labelTitle{
//            label.text = "This is a title"
//        }
//        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellid", for: indexPath)
        cell.textLabel?.text = people[indexPath.row].firstname
        cell.detailTextLabel?.text = people[indexPath.row].lastname

        
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
            if segue.identifier == "mysegue"{
                let nextScene = segue.destination as? PersonViewController
                
                let indexPath = self.tableView.indexPathForSelectedRow
                nextScene?.labelString1 = people[(indexPath?.row)!].firstname
                nextScene?.labelString2 = people[(indexPath?.row)!].lastname
                nextScene?.labelString3 = people[(indexPath?.row)!].age!
                nextScene?.labelString4 = people[(indexPath?.row)!].city

            }
        }
            
        }

