//
//  addViewController.swift
//  KimHyunJoong-hw5
//
//  Created by Hyun Joong Kim on 2/20/17.
//  Copyright © 2017 Hyun Joong Kim. All rights reserved.
//

import UIKit
import CoreData

class addViewController: UIViewController {

    var _party:String = "Democrat"
    var people: [NSManagedObject] = []
    @IBOutlet weak var returnLabel: UILabel!
    @IBOutlet weak var segmentControl: UISegmentedControl!
    @IBOutlet weak var firstName: UITextField!
    @IBOutlet weak var lastName: UITextField!
    @IBOutlet weak var state: UITextField!
    @IBAction func party(_ sender: Any) {
        
        switch self.segmentControl.selectedSegmentIndex
        {
        case 0:
            self._party = "Democrat"
        case 1:
            self._party = "Republican"
        default:
            break
        }
        
    }
    @IBAction func save(_ sender: Any) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let managedContext = appDelegate.managedObjectContext
        
        // Create the entity we want to save
        let entity = NSEntityDescription.entity(forEntityName: "Person", in: managedContext)
        let person = NSManagedObject(entity: entity!, insertInto:managedContext)
        
        person.setValue(firstName.text, forKey: "firstName")
        person.setValue(lastName.text, forKey: "lastName")
        person.setValue(state.text, forKey: "state")
        person.setValue(self._party, forKey: "party")
        
        do {
            try managedContext.save()
        } catch {
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
        
        people.append(person)
        print("you have added the candidate")
        returnLabel.text = "Candidate Saved!"
        returnLabel.isHidden = false
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Add Candidate"
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "Back", style: UIBarButtonItemStyle.plain, target: nil, action: nil)

        returnLabel.isHidden = true
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    

}
