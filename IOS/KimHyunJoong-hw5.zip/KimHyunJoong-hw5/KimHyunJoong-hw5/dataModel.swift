//
//  dataModel.swift
//  KimHyunJoong-hw5
//
//  Created by Hyun Joong Kim on 2/20/17.
//  Copyright © 2017 Hyun Joong Kim. All rights reserved.
//

import Foundation

class dataModel {
    
    fileprivate var list:[person] = [person]()
    
    init() {
    }
    
    func count() -> Int {
        return list.count
    }
    
    func get(index:Int) -> person {
        if index < list.count {
            return list[index]
        } else {
            return list[index]
        }
    }
    
    func add(person:person) {
        list.append(person)
    }
    
    func delete(index:Int) {
        if index < list.count {
            list.remove(at: index)
        }
    }

    
    
    
}
