//
//  personClass.swift
//  KimHyunJoong-hw5
//
//  Created by Hyun Joong Kim on 2/20/17.
//  Copyright © 2017 Hyun Joong Kim. All rights reserved.
//

import Foundation

class person{
    fileprivate var firstName:String = ""
    fileprivate var lastName:String = ""
    fileprivate var state:String = ""
    fileprivate var party:String = ""
    
    
    init(firstName:String, lastName:String, state:String, party:String){
        self.firstName = firstName
        self.lastName = lastName
        self.state = state
        self.party = party
    }
}
