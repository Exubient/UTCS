//
//  detailViewController.swift
//  KimHyunJoong-hw5
//
//  Created by Hyun Joong Kim on 2/20/17.
//  Copyright © 2017 Hyun Joong Kim. All rights reserved.
//

import UIKit
import CoreData

class detailViewController: UIViewController {
    var people = [NSManagedObject]()
    @IBOutlet weak var detail_first: UILabel?
    @IBOutlet weak var detail_last: UILabel?
    @IBOutlet weak var detail_state: UILabel?
    @IBOutlet weak var detail_party: UILabel?
    var indx:Int?

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Candidate Detail"
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "Back", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName:"Person")
        var fetchedResults:[NSManagedObject]? = nil
        
        do {
            try fetchedResults = managedContext.fetch(fetchRequest) as? [NSManagedObject]
        } catch {
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
        
        if let results = fetchedResults {
            people = results
            print("fetch has been done")
            var person = people[indx!]
            detail_first?.text = (person.value(forKey: "firstName") as? String)!
            detail_last?.text = (person.value(forKey: "lastName") as? String)!
            detail_state?.text = (person.value(forKey: "state") as? String)!
            detail_party?.text = (person.value(forKey: "party") as? String)!
        } else {
            print("Could not fetch")
        }
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
