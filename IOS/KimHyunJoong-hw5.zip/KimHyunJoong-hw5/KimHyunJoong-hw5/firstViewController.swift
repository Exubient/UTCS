//
//  firstViewController.swift
//  KimHyunJoong-hw5
//
//  Created by Hyun Joong Kim on 2/20/17.
//  Copyright © 2017 Hyun Joong Kim. All rights reserved.
//

import UIKit

class firstViewController: UIViewController {



    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Candidate Manager"

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "addSegue"{
            let nextScene = segue.destination as? addViewController
            navigationItem.title = nil
        }
        if segue.identifier == "showSegue"{
            let nextScene = segue.destination as? MainTableViewController
            navigationItem.title = nil
        }
    }
    
    }
