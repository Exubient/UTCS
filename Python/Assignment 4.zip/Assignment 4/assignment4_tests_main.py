def test_addition():
    """1+1 == 2"""
    assert 1+1 == 2, "Yay"

def test_power():
    """Test power operator (broken test)"""
    assert 2^4 == 16, "Boo!!"
