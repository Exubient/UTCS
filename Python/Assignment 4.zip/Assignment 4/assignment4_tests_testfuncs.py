def test_power():
    """Test power operator"""
    return 2**4 == 16

test_name = "Not a function"


